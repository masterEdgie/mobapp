package com.example.settingsactivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

public class DialogNewNote extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_new_note, null);

        final EditText editTitle = dialogView.findViewById(R.id.editTitle);
        final EditText editDescription = dialogView.findViewById(R.id.editDescription);
        final CheckBox checkBoxIdea = dialogView.findViewById(R.id.checkBoxIdea);
        final CheckBox checkBoxTodo = dialogView.findViewById(R.id.checkBoxTodo);
        final CheckBox checkBoxImportant = dialogView.findViewById(R.id.checkBoxImportant);

        builder.setView(dialogView)
                .setMessage(getString(R.string.add_new_note))
                .setPositiveButton(getString(R.string.ok_button), (dialog, which) -> {
                    Note newNote = new Note();
                    newNote.setTitle(editTitle.getText().toString());
                    newNote.setDescription(editDescription.getText().toString());
                    newNote.setIdea(checkBoxIdea.isChecked());
                    newNote.setTodo(checkBoxTodo.isChecked());
                    newNote.setImportant(checkBoxImportant.isChecked());

                    MainActivity activity = (MainActivity) getActivity();
                    if (activity != null) {
                        activity.createNewNote(newNote);
                    }
                })
                .setNegativeButton(getString(R.string.cancel_button), null);

        return builder.create();
    }
}